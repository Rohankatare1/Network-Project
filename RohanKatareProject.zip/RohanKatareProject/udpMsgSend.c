
#define WIN // WIN for Winsock and BSD for BSD sockets

//----- Include files ---------------------------------------------------------
#include <stdio.h>      // Needed for printf()
#include <string.h>     // Needed for strcpy()
#include <stdlib.h>     // Needed for atoi()
#ifdef WIN
#include <windows.h>    // Needed for all Winsock stuff
#endif

//===== Main program ==========================================================
int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Usage: %s <IP> <PORT> <MESSAGE>\n", argv[0]);
        return -1;
    }

    char *ip = argv[1];
    int port = atoi(argv[2]);
    char *message = argv[3];

#ifdef WIN
    WSADATA wsaData;
    WORD wVersionRequested = MAKEWORD(1, 1);
    if (WSAStartup(wVersionRequested, &wsaData) != 0)
    {
        printf("WSAStartup failed\n");
        return -1;
    }
#endif

    int sock;
    struct sockaddr_in server_addr;
    int retcode;

    // Create socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0)
    {
        printf("*** ERROR - socket() failed\n");
        return -1;
    }

    // Set up server address struct
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr(ip);

    // Send message
    retcode = sendto(sock, message, strlen(message) + 1, 0,
                     (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (retcode < 0)
    {
        printf("*** ERROR - sendto() failed\n");
        return -1;
    }

    printf("Sent \"%s\" to %s:%d\n", message, ip, port);

#ifdef WIN
    closesocket(sock);
    WSACleanup();
#else
    close(sock);
#endif

    return 0;
}
//=============================================================================
